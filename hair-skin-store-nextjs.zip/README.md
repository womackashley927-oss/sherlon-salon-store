# Sherlon Salon — Hair & Skin Store (Next.js + Tailwind)

A simple, fast storefront ready to deploy on **Vercel**.

## Local Dev
```bash
npm install
npm run dev
```
Visit http://localhost:3000

## Deploy to Vercel
1. Create a new empty GitHub repo (e.g. `sherlon-salon-store`).
2. Upload these files to that repo (or push with Git).
3. Go to https://vercel.com/new, click **Import Git Repository**, choose your repo.
4. Framework preset: **Next.js**. Build command: `next build` (auto). Output: `.next` (auto).
5. Click **Deploy**.

> After deploy, you can set a custom domain and enable analytics in the Vercel dashboard.

## Customize
- Edit product list in `app/page.jsx` (the `CATALOG` array).
- Change brand text in the header and footer.
- Tailwind styles live in `app/globals.css`.
