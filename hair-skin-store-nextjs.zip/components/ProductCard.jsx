'use client';
import React from 'react';

export default function ProductCard({ product, onAdd }) {
  const [size, setSize] = React.useState(product.sizeOptions?.[0] || '');
  const [scent, setScent] = React.useState(product.scentOptions?.[0] || '');

  const ratingStars = Math.round(product.rating || 0);
  return (
    <div className="h-full rounded-2xl border bg-white shadow-sm hover:shadow-md transition-shadow">
      <div className="p-4 space-y-3">
        <div className="h-40 w-full rounded-xl bg-gradient-to-br from-pink-500 via-fuchsia-500 to-purple-600 text-white grid place-items-center">
          <div className="text-sm font-semibold">{product.category}</div>
        </div>
        <div className="text-lg font-semibold leading-tight">{product.name}</div>
        <div className="text-sm text-neutral-600 min-h-10">{product.description}</div>

        <div className="flex items-center gap-2 text-sm">
          <div className="flex gap-0.5">
            {Array.from({length:5}).map((_,i)=>(
              <span key={i} className={
                'inline-block h-4 w-4 ' + (i < ratingStars ? 'text-yellow-400' : 'text-neutral-300')
              }>★</span>
            ))}
          </div>
          <span>({product.reviews})</span>
          {product.isNew && <span className="ml-auto inline-block text-xs px-2 py-0.5 rounded bg-neutral-100">New</span>}
          {!product.inStock && <span className="ml-auto inline-block text-xs px-2 py-0.5 rounded bg-red-100 text-red-700">Sold out</span>}
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-xl font-semibold">${product.price.toFixed(2)}</span>
          {product.originalPrice && (
            <span className="line-through text-neutral-400">${product.originalPrice.toFixed(2)}</span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          {product.sizeOptions && (
            <select value={size} onChange={e=>setSize(e.target.value)} className="rounded-xl border px-3 py-2">
              {product.sizeOptions.map(s=>(<option key={s} value={s}>{s}</option>))}
            </select>
          )}
          {product.scentOptions && (
            <select value={scent} onChange={e=>setScent(e.target.value)} className="rounded-xl border px-3 py-2">
              {product.scentOptions.map(s=>(<option key={s} value={s}>{s}</option>))}
            </select>
          )}
        </div>

        <button
          className="w-full rounded-xl bg-neutral-900 text-white py-2.5 disabled:opacity-50"
          disabled={!product.inStock}
          onClick={()=>onAdd(product, { size, scent })}
        >
          Add to cart
        </button>
      </div>
    </div>
  );
}
