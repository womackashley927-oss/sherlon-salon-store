'use client';
import React from 'react';
import ProductCard from '../components/ProductCard';
import './globals.css';

const CATALOG = [
  {
    id: 'flaxseed-cream',
    name: 'Naturally Soft Flaxseed Cream',
    description: 'Curl‑defining moisture cream with flaxseed gel + shea. No crunch, all shine.',
    price: 16,
    originalPrice: 20,
    rating: 4.8,
    reviews: 312,
    category: 'Hair',
    tags: ['moisturize', 'define', 'leave‑in'],
    sizeOptions: ['4oz', '8oz'],
    scentOptions: ['Unscented', 'Coconut', 'Lavender'],
    isNew: true,
    inStock: true,
  },
  {
    id: 'growth-oil',
    name: 'Herbal Growth Oil',
    description: 'Ayurvedic scalp blend with rosemary, amla & black seed to soothe and stimulate.',
    price: 18,
    rating: 4.7,
    reviews: 189,
    category: 'Hair',
    tags: ['scalp', 'growth', 'shine'],
    sizeOptions: ['2oz', '4oz'],
    scentOptions: ['Herbal', 'Citrus'],
    inStock: true,
  },
  {
    id: 'butter-gloss',
    name: 'Butter Gloss Body Cream',
    description: 'Whipped mango & kokum butter that melts on contact for 24‑hour glow.',
    price: 22,
    rating: 4.9,
    reviews: 421,
    category: 'Skin',
    tags: ['body', 'butter', 'glow'],
    sizeOptions: ['6oz', '10oz'],
    scentOptions: ['Vanilla', 'Amber', 'Unscented'],
    inStock: true,
  },
  {
    id: 'face-serum',
    name: 'Bright Dew Face Serum',
    description: 'Niacinamide + hyaluronic + licorice root for bouncy, even‑tone skin.',
    price: 28,
    rating: 4.6,
    reviews: 137,
    category: 'Skin',
    tags: ['serum', 'brighten', 'hydrate'],
    sizeOptions: ['1oz'],
    inStock: true,
  },
  {
    id: 'edge-tamer',
    name: 'Silk Hold Edge Tamer',
    description: 'Flake‑free 24h hold with silk proteins and aloe.',
    price: 12,
    rating: 4.4,
    reviews: 203,
    category: 'Hair',
    tags: ['style', 'edges'],
    inStock: false,
  },
];

function currency(n){ return n.toLocaleString(undefined,{style:'currency', currency:'USD'}) }

export default function Page(){
  const [query, setQuery] = React.useState('');
  const [category, setCategory] = React.useState('All');
  const [sort, setSort] = React.useState('featured');
  const [filters, setFilters] = React.useState({ inStockOnly: true, isNewOnly: false, tag: 'all' });
  const [cartOpen, setCartOpen] = React.useState(false);
  const [cart, setCart] = React.useState(()=>{
    if (typeof window === 'undefined') return [];
    try { return JSON.parse(localStorage.getItem('cart') || '[]') } catch { return [] }
  });

  React.useEffect(()=>{ localStorage.setItem('cart', JSON.stringify(cart)) }, [cart]);

  const products = React.useMemo(()=>{
    let list = [...CATALOG];
    if (category !== 'All') list = list.filter(p=>p.category===category);
    if (filters.inStockOnly) list = list.filter(p=>p.inStock);
    if (filters.isNewOnly) list = list.filter(p=>p.isNew);
    if (filters.tag !== 'all') list = list.filter(p=>p.tags.includes(filters.tag));
    if (query.trim()){
      const q = query.toLowerCase();
      list = list.filter(p=>`${p.name} ${p.description} ${p.tags.join(' ')}`.toLowerCase().includes(q));
    }
    if (sort==='price-asc') list.sort((a,b)=>a.price-b.price);
    if (sort==='price-desc') list.sort((a,b)=>b.price-a.price);
    if (sort==='rating') list.sort((a,b)=>b.rating-a.rating);
    return list;
  }, [query, category, sort, filters]);

  const subtotal = cart.reduce((s,i)=>s+i.product.price*i.qty, 0);

  function addToCart(product, variant){
    setCart(prev=>{
      const idx = prev.findIndex(i=> i.product.id===product.id && JSON.stringify(i.variant)===JSON.stringify(variant));
      if (idx>=0){ const next=[...prev]; next[idx]={...next[idx], qty: next[idx].qty+1}; return next; }
      return [...prev, { product, qty:1, variant }];
    });
    setCartOpen(true);
  }

  function updateQty(id, delta, variant){
    setCart(prev=>prev.map(i=> (i.product.id===id && JSON.stringify(i.variant)===JSON.stringify(variant)) ? {...i, qty: Math.max(1, i.qty+delta)} : i));
  }
  function removeItem(id, variant){
    setCart(prev=>prev.filter(i=> !(i.product.id===id && JSON.stringify(i.variant)===JSON.stringify(variant))));
  }

  return (
    <div>
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-pink-500 via-fuchsia-500 to-purple-600 grid place-items-center text-white font-bold">S</div>
          <div className="flex-1">
            <div className="font-semibold leading-none">Sherlon Salon</div>
            <div className="text-xs text-neutral-500">Nourish. Glow. Repeat.</div>
          </div>
          <div className="hidden md:flex items-center gap-2">
            <div className="relative">
              <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products…" className="pl-3 pr-3 py-2 rounded-xl border w-64" />
            </div>
            <select value={sort} onChange={(e)=>setSort(e.target.value)} className="rounded-xl border px-3 py-2">
              <option value="featured">Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
          </div>
          <button onClick={()=>setCartOpen(true)} className="rounded-xl bg-neutral-900 text-white px-4 py-2">
            Cart <span className="ml-2 inline-block text-xs bg-white text-neutral-900 px-2 py-0.5 rounded">{cart.reduce((s,i)=>s+i.qty,0)}</span>
          </button>
        </div>

        {/* Mobile search */}
        <div className="md:hidden border-t">
          <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-2">
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products…" className="pl-3 pr-3 py-2 rounded-xl border flex-1" />
            <select value={sort} onChange={(e)=>setSort(e.target.value)} className="rounded-xl border px-3 py-2">
              <option value="featured">Featured</option>
              <option value="price-asc">Low → High</option>
              <option value="price-desc">High → Low</option>
              <option value="rating">Top Rated</option>
            </select>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-br from-pink-500 via-fuchsia-500 to-purple-600 text-white">
        <div className="max-w-6xl mx-auto px-4 py-12 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">
              Healthy hair & glowing skin, the <span className="underline decoration-white/60">Sherlon</span> way.
            </h1>
            <p className="mt-3 text-white/90 max-w-prose">Small‑batch, clean ingredients. Loved by curls, coils, and melanated skin.</p>
            <div className="mt-5 flex gap-3">
              <button className="rounded-xl bg-white text-neutral-900 px-4 py-2" onClick={()=>setCategory('Hair')}>Shop Hair</button>
              <button className="rounded-xl border border-white/70 px-4 py-2" onClick={()=>setCategory('Skin')}>Shop Skin</button>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="aspect-[4/3] rounded-3xl bg-white/10 backdrop-blur p-6">
              <div className="h-full w-full rounded-2xl border border-white/20 grid place-items-center text-center">
                <div>
                  <div className="mx-auto h-10 w-10 grid place-items-center rounded-full bg-white/20">📦</div>
                  <p className="mt-2 text-sm opacity-90">Fast shipping • Secure checkout • Handmade fresh</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tabs / Filters */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-wrap items-center gap-2 mb-4">
          {['All','Hair','Skin'].map(v=>(
            <button key={v} onClick={()=>setCategory(v)} className={'px-3 py-1.5 rounded-xl border ' + (category===v ? 'bg-neutral-900 text-white' : 'bg-white')}>{v}</button>
          ))}
          <div className="ml-auto flex items-center gap-3 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={filters.inStockOnly} onChange={e=>setFilters(f=>({...f, inStockOnly: e.target.checked}))} />
              In stock only
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={filters.isNewOnly} onChange={e=>setFilters(f=>({...f, isNewOnly: e.target.checked}))} />
              New arrivals
            </label>
            <select value={filters.tag} onChange={e=>setFilters(f=>({...f, tag: e.target.value}))} className="rounded-xl border px-3 py-2">
              <option value="all">All tags</option>
              {['moisturize','define','leave‑in','scalp','growth','shine','body','butter','glow','serum','brighten','hydrate','style','edges'].map(t=>(
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {products.map(p => (
            <ProductCard key={p.id} product={p} onAdd={addToCart} />
          ))}
        </div>
        {products.length===0 && <div className="py-16 text-center text-neutral-500">No products match your filters.</div>}
      </div>

      {/* Benefits */}
      <section className="border-t bg-white">
        <div className="max-w-6xl mx-auto px-4 py-6 grid sm:grid-cols-3 gap-4 text-sm">
          <div className="flex items-center gap-3"><span>📦</span><span>Fast, trackable shipping</span></div>
          <div className="flex items-center gap-3"><span>🌿</span><span>Clean, sensitive‑skin friendly</span></div>
          <div className="flex items-center gap-3"><span>⭐</span><span>4.8★ average reviews</span></div>
        </div>
      </section>

      {/* Newsletter / Contact */}
      <section className="bg-neutral-50 border-t">
        <div className="max-w-6xl mx-auto px-4 py-10 grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold">Get glow mail</h2>
            <p className="text-sm text-neutral-600 mt-1">Drops, discounts, and tips for healthy hair & skin.</p>
            <div className="mt-4 flex gap-2">
              <input placeholder="Email address" className="rounded-xl border px-3 py-2" />
              <button className="rounded-xl bg-neutral-900 text-white px-4">Subscribe</button>
            </div>
          </div>
          <div>
            <h2 className="text-xl font-semibold">Questions?</h2>
            <p className="text-sm text-neutral-600 mt-1">Tell us what you need help with.</p>
            <textarea placeholder="Your message" className="mt-3 rounded-xl border w-full p-3 h-28" />
            <div className="mt-2 text-xs text-neutral-500">We reply within 24–48 hours.</div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t">
        <div className="max-w-6xl mx-auto px-4 py-8 text-sm text-neutral-600 grid md:grid-cols-2 gap-4">
          <div>
            <div className="font-semibold text-neutral-800">Sherlon Salon</div>
            <div>Nourish. Glow. Repeat.</div>
          </div>
          <div className="md:text-right">© {new Date().getFullYear()} Sherlon Salon. All rights reserved.</div>
        </div>
      </footer>

      {/* Cart Drawer (simple) */}
      {cartOpen && (
        <div className="fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setCartOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-xl p-4 overflow-y-auto">
            <div className="text-lg font-semibold">Your Cart</div>
            <div className="mt-4 space-y-4">
              {cart.length === 0 && <div className="text-neutral-500 text-sm">Your cart is empty.</div>}
              {cart.map((item, idx)=>(
                <div key={idx} className="flex gap-3 border rounded-xl p-3 items-start">
                  <div className="h-16 w-16 rounded-lg bg-gradient-to-br from-pink-500 via-fuchsia-500 to-purple-600" />
                  <div className="flex-1">
                    <div className="font-medium leading-tight">{item.product.name}</div>
                    <div className="text-xs text-neutral-500">
                      {item.variant?.size && <span>{item.variant.size}</span>}
                      {item.variant?.size && item.variant?.scent && <span> • </span>}
                      {item.variant?.scent && <span>{item.variant.scent}</span>}
                    </div>
                    <div className="mt-1 text-sm">{currency(item.product.price)} each</div>
                    <div className="mt-2 flex items-center gap-2">
                      <button className="h-7 w-7 rounded-lg border" onClick={()=>updateQty(item.product.id, -1, item.variant)}>-</button>
                      <div className="w-8 text-center text-sm">{item.qty}</div>
                      <button className="h-7 w-7 rounded-lg border" onClick={()=>updateQty(item.product.id, 1, item.variant)}>+</button>
                      <button className="ml-auto text-sm text-red-600" onClick={()=>removeItem(item.product.id, item.variant)}>Remove</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 border-t pt-4">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span className="font-medium">{currency(subtotal)}</span>
              </div>
              <div className="text-xs text-neutral-500 mt-1">Taxes and shipping calculated at checkout.</div>
              <button className="w-full mt-4 rounded-xl bg-neutral-900 text-white py-2.5 disabled:opacity-50" disabled={cart.length===0} onClick={()=>alert('Connect Stripe to enable checkout.')}>
                Checkout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
